import InflacionNucleoSection from "../components/sections/InflacionNucleoSection";
import MapaInflacionSection from "../components/sections/MapaInflacionSection";
import "../styles/recursos.css";

function Recursos() {
  return (
    <div className="recursos-comic-page">
      <header className="recursos-comic-header">
        <h1>Recursos</h1>
        <p>Tablero de consulta rápida con estética cómic.</p>
      </header>

      <div className="recursos-comic-grid">
        <section className="recursos-comic-card">
          <h2>Inflación núcleo</h2>
          <InflacionNucleoSection />
        </section>

        <section className="recursos-comic-card">
          <h2>Mapa de inflación por región</h2>
          <MapaInflacionSection />
        </section>
      </div>
    </div>
  );
}

export default Recursos;