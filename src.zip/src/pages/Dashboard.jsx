import InflationSection from "../components/sections/InflationSection";
import ExchangeRateSection from "../components/sections/ExchangeRateSection";
import ReserveSection from "../components/sections/ReserveSection";

function Dashboard() {
  return (
    <div>
      <h1>Dashboard macroeconómico</h1>

      <div className="dashboard-grid">
        <InflationSection />
        <ExchangeRateSection />
        <ReserveSection />
      </div>
    </div>
  );
}

export default Dashboard;